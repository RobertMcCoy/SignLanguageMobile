# SignLanguageMobile
Using React Native &amp; Keras.js in conjunction with a CNN we are attempting to translate the static (non-moving) letters of American Sign Language
